# Secure Blockchain Voting System

A secure, transparent, and tamper-proof voting system utilizing blockchain technology. This system authenticates voters using their voter IDs while ensuring privacy and integrity.

## Features

- Blockchain-based vote storage
- Secure voter authentication
- Encrypted voter details
- Real-time vote counting
- Chain validity verification
- Prevention of double voting
- RESTful API interface

## Technical Stack

- Python 3.8+
- Flask for API endpoints
- Cryptography for encryption
- Custom blockchain implementation
- JSON for data storage

## Installation

1. Clone the repository
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

## API Endpoints

### Register Voter
- POST `/register_voter`
- Body: 
  ```json
  {
    "voter_id": "string",
    "voter_details": {
      "name": "string",
      "age": "number",
      "address": "string"
    }
  }
  ```

### Cast Vote
- POST `/cast_vote`
- Body:
  ```json
  {
    "voter_id": "string",
    "candidate_id": "string"
  }
  ```

### Get Results
- GET `/get_results`

### Verify Chain
- GET `/verify_chain`

### Check Voter Status
- GET `/voter_status/<voter_id>`

## Security Features

1. Encrypted voter details
2. Hashed voter IDs
3. Blockchain immutability
4. Double voting prevention
5. Chain validity verification

## Usage Example

1. Register a voter:
```bash
curl -X POST http://localhost:5000/register_voter \
  -H "Content-Type: application/json" \
  -d '{"voter_id": "V123", "voter_details": {"name": "John Doe", "age": 25}}'
```

2. Cast a vote:
```bash
curl -X POST http://localhost:5000/cast_vote \
  -H "Content-Type: application/json" \
  -d '{"voter_id": "V123", "candidate_id": "C1"}'
```

3. Get results:
```bash
curl http://localhost:5000/get_results
```

## Security Considerations

- Keep the encryption keys secure
- Use HTTPS in production
- Regularly backup the blockchain data
- Monitor for suspicious activities
- Implement rate limiting
- Use proper authentication mechanisms

## Contributing

1. Fork the repository
2. Create your feature branch
3. Commit your changes
4. Push to the branch
5. Create a new Pull Request
