import hashlib
import json
import time
from typing import List, Dict
from cryptography.fernet import Fernet

class Block:
    def __init__(self, index: int, votes: List[Dict], timestamp: float, previous_hash: str):
        self.index = index
        self.timestamp = timestamp
        self.votes = votes
        self.previous_hash = previous_hash
        self.nonce = 0
        self.hash = self.calculate_hash()

    def calculate_hash(self) -> str:
        block_string = json.dumps({
            "index": self.index,
            "timestamp": self.timestamp,
            "votes": self.votes,
            "previous_hash": self.previous_hash,
            "nonce": self.nonce
        }, sort_keys=True).encode()
        return hashlib.sha256(block_string).hexdigest()

class VotingBlockchain:
    def __init__(self):
        self.chain = [self.create_genesis_block()]
        self.difficulty = 2
        self.pending_votes = []
        self.voters = set()  # Keep track of voters who have already voted
        self.encryption_key = Fernet.generate_key()
        self.cipher_suite = Fernet(self.encryption_key)

    def create_genesis_block(self) -> Block:
        return Block(0, [], time.time(), "0")

    def get_last_block(self) -> Block:
        return self.chain[-1]

    def add_vote(self, voter_id: str, candidate_id: str) -> bool:
        if voter_id in self.voters:
            return False  # Voter has already voted
        
        # Encrypt voter data
        encrypted_voter_id = self.cipher_suite.encrypt(voter_id.encode()).decode()
        
        vote = {
            "voter_id": encrypted_voter_id,
            "candidate_id": candidate_id,
            "timestamp": time.time()
        }
        
        self.pending_votes.append(vote)
        self.voters.add(voter_id)
        return True

    def mine_pending_votes(self) -> Block:
        if not self.pending_votes:
            return None

        block = Block(
            len(self.chain),
            self.pending_votes,
            time.time(),
            self.get_last_block().hash
        )

        # Proof of Work
        while block.hash[:self.difficulty] != "0" * self.difficulty:
            block.nonce += 1
            block.hash = block.calculate_hash()

        self.chain.append(block)
        self.pending_votes = []
        return block

    def is_chain_valid(self) -> bool:
        for i in range(1, len(self.chain)):
            current_block = self.chain[i]
            previous_block = self.chain[i-1]

            if current_block.hash != current_block.calculate_hash():
                return False

            if current_block.previous_hash != previous_block.hash:
                return False

        return True

    def get_vote_count(self) -> Dict[str, int]:
        vote_count = {}
        for block in self.chain[1:]:  # Skip genesis block
            for vote in block.votes:
                candidate_id = vote["candidate_id"]
                vote_count[candidate_id] = vote_count.get(candidate_id, 0) + 1
        return vote_count
