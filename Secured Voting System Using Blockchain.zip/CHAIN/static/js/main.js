document.addEventListener('DOMContentLoaded', function() {
    // Tab switching functionality
    const tabs = document.querySelectorAll('.tab');
    const tabContents = document.querySelectorAll('.tab-content');

    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            const targetId = tab.getAttribute('data-target');
            
            // Update active tab
            tabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            
            // Update active content
            tabContents.forEach(content => {
                content.classList.remove('active');
                if (content.id === targetId) {
                    content.classList.add('active');
                }
            });
        });
    });

    // Form submission handlers
    const registerForm = document.getElementById('registerForm');
    const voteForm = document.getElementById('voteForm');
    const verifyForm = document.getElementById('verifyForm');

    registerForm?.addEventListener('submit', async (e) => {
        e.preventDefault();
        const formData = {
            voter_id: document.getElementById('registerId').value,
            voter_details: {
                name: document.getElementById('registerName').value,
                age: document.getElementById('registerAge').value,
                address: document.getElementById('registerAddress').value
            }
        };

        try {
            const response = await fetch('/register_voter', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(formData)
            });
            
            const result = await response.json();
            showAlert(response.ok ? 'success' : 'error', result.message || result.error);
        } catch (error) {
            showAlert('error', 'Failed to register voter');
        }
    });

    voteForm?.addEventListener('submit', async (e) => {
        e.preventDefault();
        const formData = {
            voter_id: document.getElementById('voteId').value,
            candidate_id: document.getElementById('candidateId').value
        };

        try {
            const response = await fetch('/cast_vote', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(formData)
            });
            
            const result = await response.json();
            showAlert(response.ok ? 'success' : 'error', result.message || result.error);
            if (response.ok) {
                updateResults();
            }
        } catch (error) {
            showAlert('error', 'Failed to cast vote');
        }
    });

    verifyForm?.addEventListener('submit', async (e) => {
        e.preventDefault();
        const voterId = document.getElementById('verifyId').value;

        try {
            const response = await fetch(`/voter_status/${voterId}`);
            const result = await response.json();
            
            let message = `Voter Status:\n`;
            message += `Registered: ${result.registered ? 'Yes' : 'No'}\n`;
            message += `Has Voted: ${result.has_voted ? 'Yes' : 'No'}`;
            
            showAlert('success', message);
        } catch (error) {
            showAlert('error', 'Failed to verify voter status');
        }
    });

    // Results updating functionality
    async function updateResults() {
        try {
            const response = await fetch('/get_results');
            const data = await response.json();
            
            const resultsContainer = document.getElementById('resultsContainer');
            resultsContainer.innerHTML = '';
            
            Object.entries(data.results).forEach(([candidate, votes]) => {
                const resultCard = document.createElement('div');
                resultCard.className = 'result-card';
                resultCard.innerHTML = `
                    <h3>Candidate ${candidate}</h3>
                    <p>${votes}</p>
                    <span>votes</span>
                `;
                resultsContainer.appendChild(resultCard);
            });
        } catch (error) {
            showAlert('error', 'Failed to update results');
        }
    }

    // Utility function to show alerts
    function showAlert(type, message) {
        const alertsContainer = document.getElementById('alerts');
        const alert = document.createElement('div');
        alert.className = `alert alert-${type}`;
        alert.textContent = message;
        
        alertsContainer.innerHTML = '';
        alertsContainer.appendChild(alert);
        
        setTimeout(() => {
            alert.remove();
        }, 5000);
    }

    // Initial results load
    updateResults();
    
    // Periodic results update
    setInterval(updateResults, 30000);
});
