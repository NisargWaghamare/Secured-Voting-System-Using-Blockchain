import hashlib
import json
from typing import Dict, Optional
from cryptography.fernet import Fernet

class VoterAuthentication:
    def __init__(self):
        self.registered_voters = {}  # Dictionary to store voter information
        self.encryption_key = Fernet.generate_key()
        self.cipher_suite = Fernet(self.encryption_key)

    def register_voter(self, voter_id: str, voter_details: Dict) -> bool:
        """
        Register a new voter with their details
        """
        if voter_id in self.registered_voters:
            return False

        # Hash the voter ID for secure storage
        hashed_voter_id = hashlib.sha256(voter_id.encode()).hexdigest()
        
        # Encrypt voter details
        encrypted_details = self.cipher_suite.encrypt(
            json.dumps(voter_details).encode()
        )
        
        self.registered_voters[hashed_voter_id] = {
            "details": encrypted_details,
            "has_voted": False
        }
        return True

    def authenticate_voter(self, voter_id: str) -> Optional[Dict]:
        """
        Authenticate a voter and return their details if valid
        """
        hashed_voter_id = hashlib.sha256(voter_id.encode()).hexdigest()
        
        if hashed_voter_id not in self.registered_voters:
            return None
            
        voter_data = self.registered_voters[hashed_voter_id]
        if voter_data["has_voted"]:
            return None
            
        # Decrypt voter details
        decrypted_details = self.cipher_suite.decrypt(voter_data["details"])
        return json.loads(decrypted_details)

    def mark_voter_voted(self, voter_id: str) -> bool:
        """
        Mark a voter as having voted
        """
        hashed_voter_id = hashlib.sha256(voter_id.encode()).hexdigest()
        
        if hashed_voter_id not in self.registered_voters:
            return False
            
        self.registered_voters[hashed_voter_id]["has_voted"] = True
        return True

    def verify_voter_status(self, voter_id: str) -> Dict:
        """
        Check if a voter is registered and whether they have voted
        """
        hashed_voter_id = hashlib.sha256(voter_id.encode()).hexdigest()
        
        if hashed_voter_id not in self.registered_voters:
            return {
                "registered": False,
                "has_voted": False
            }
            
        return {
            "registered": True,
            "has_voted": self.registered_voters[hashed_voter_id]["has_voted"]
        }
