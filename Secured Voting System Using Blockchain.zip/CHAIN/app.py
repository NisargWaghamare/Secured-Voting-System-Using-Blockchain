from flask import Flask, request, jsonify, render_template
from blockchain import VotingBlockchain
from voter_auth import VoterAuthentication
import json

app = Flask(__name__)

# Initialize our blockchain and authentication system
blockchain = VotingBlockchain()
voter_auth = VoterAuthentication()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register_voter', methods=['POST'])
def register_voter():
    data = request.get_json()
    voter_id = data.get('voter_id')
    voter_details = data.get('voter_details')
    
    if not voter_id or not voter_details:
        return jsonify({"error": "Missing required fields"}), 400
        
    success = voter_auth.register_voter(voter_id, voter_details)
    if success:
        return jsonify({"message": "Voter registered successfully"}), 201
    else:
        return jsonify({"error": "Voter already registered"}), 400

@app.route('/cast_vote', methods=['POST'])
def cast_vote():
    data = request.get_json()
    voter_id = data.get('voter_id')
    candidate_id = data.get('candidate_id')
    
    if not voter_id or not candidate_id:
        return jsonify({"error": "Missing required fields"}), 400
        
    # Authenticate voter
    voter_details = voter_auth.authenticate_voter(voter_id)
    if not voter_details:
        return jsonify({"error": "Invalid voter ID or voter has already voted"}), 401
        
    # Add vote to blockchain
    success = blockchain.add_vote(voter_id, candidate_id)
    if success:
        voter_auth.mark_voter_voted(voter_id)
        # Mine the block
        blockchain.mine_pending_votes()
        return jsonify({"message": "Vote cast successfully"}), 201
    else:
        return jsonify({"error": "Failed to cast vote"}), 400

@app.route('/get_results', methods=['GET'])
def get_results():
    results = blockchain.get_vote_count()
    return jsonify({"results": results}), 200

@app.route('/verify_chain', methods=['GET'])
def verify_chain():
    is_valid = blockchain.is_chain_valid()
    return jsonify({"chain_valid": is_valid}), 200

@app.route('/voter_status/<voter_id>', methods=['GET'])
def voter_status(voter_id):
    status = voter_auth.verify_voter_status(voter_id)
    return jsonify(status), 200

if __name__ == '__main__':
    app.run(debug=True, port=5000)
